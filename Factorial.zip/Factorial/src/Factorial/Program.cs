﻿class Program{
    static void Main(){
        Console.WriteLine($"El factorial de 5 es: {factorial_for(5)}");
        Console.WriteLine($"El factorial de 5 es: {factorial_while(5)}");
    }
    
    static int factorial_for(int n){
        int r = 1;
        for(int i = 1; i < n+1; i++){
            r = r * i;
        }
        return r;
    }
    static int factorial_while(int n){
        int r = 1;
        int i = 1;
        while (i <= n){
            r = r * i;
            i += 1;
        }
        return r;
    }
}