﻿using Library;
class Program{
    static void Main(){
        Console.WriteLine($"2000 es bisiesto? True : {bisiesto.is_leap(2000)}");
    }
} 